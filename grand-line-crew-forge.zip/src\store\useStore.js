import { create } from 'zustand';

export const useStore = create((set) => ({
  participants: [],
  crews: [],
  challenges: [
    {
      id: "ai-healthcare",
      title: "AI Healthcare Assistant",
      difficulty: "Hard",
      requiredSkills: ["Python", "Machine Learning", "Database"],
      requiredRoles: ["Captain", "Doctor", "Navigator"],
    },
    {
      id: "crypto-wallet",
      title: "Decentralized Pirate Wallet",
      difficulty: "Medium",
      requiredSkills: ["Solidity", "JavaScript", "Web Development"],
      requiredRoles: ["Captain", "Shipwright", "Sniper"],
    }
  ],
  addParticipant: (participant) => set((state) => ({ participants: [...state.participants, participant] })),
  setParticipants: (participants) => set({ participants }),
  setCrews: (crews) => set({ crews }),
  setChallenges: (challenges) => set({ challenges }),
  addChallenge: (challenge) => set((state) => ({ challenges: [...state.challenges, challenge] })),
}));
