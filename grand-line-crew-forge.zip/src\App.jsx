import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Landing from './pages/Landing';
import Recruitment from './pages/Recruitment';
import Dashboard from './pages/Dashboard';
import CrewFormation from './pages/CrewFormation';
import ChallengeAssignment from './pages/ChallengeAssignment';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Landing />} />
          <Route path="recruit" element={<Recruitment />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="formation" element={<CrewFormation />} />
          <Route path="challenge" element={<ChallengeAssignment />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
