import React from 'react';
import { useStore } from '../store/useStore';
import { secondaryCharacters } from '../lib/characters';
import { Link } from 'react-router-dom';
import ChallengeHeader from '../components/challenge/ChallengeHeader';
import ChallengeCard from '../components/challenge/ChallengeCard';
import ChallengeLibrary from '../components/challenge/ChallengeLibrary';

export default function ChallengeAssignment() {
  const { crews, challenges } = useStore();

  if (crews.length === 0) {
    return (
      <div className="max-w-4xl mx-auto p-6 my-12 text-center relative z-10 bg-darkBrown/80 backdrop-blur-md rounded-2xl border border-gold/30 shadow-2xl">
        <h1 className="text-4xl text-pirateRed mb-4 drop-shadow-md font-display">No Crews Formed</h1>
        <p className="text-xl text-parchment/80 mb-8 font-sans">You must assemble your crews before facing the challenges of the Grand Line.</p>
        <Link to="/formation" className="inline-block px-8 py-4 bg-gold/20 border-2 border-gold text-gold rounded hover:bg-gold hover:text-black font-display tracking-widest transition-all">
          Go to Crew Assembly
        </Link>
      </div>
    );
  }

  const secondaryKeys = Object.keys(secondaryCharacters);

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 my-8 relative z-10">
      <ChallengeHeader />
      
      <ChallengeLibrary />

      <div className="space-y-12">
        {crews.map((crew, idx) => {
          const challenge = challenges[idx % challenges.length];
          const compatibilityScore = Math.floor(Math.random() * 15) + 80;
          const secondaryCharKey = secondaryKeys[idx % secondaryKeys.length];
          const secondaryChar = secondaryCharacters[secondaryCharKey];

          return (
            <ChallengeCard 
              key={crew.id}
              crew={crew}
              challenge={challenge}
              compatibilityScore={compatibilityScore}
              secondaryChar={secondaryChar}
              index={idx}
            />
          );
        })}
      </div>
    </div>
  );
}
