import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Skull, Users, Map, Swords, Compass } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Navbar() {
  const location = useLocation();

  const navItems = [
    { path: '/recruit', label: 'RECRUITS', icon: Users },
    { path: '/dashboard', label: 'GRAND LINE', icon: Map },
    { path: '/formation', label: 'CREWS', icon: Swords },
    { path: '/challenge', label: 'CHALLENGES', icon: Compass },
  ];

  return (
    <header className="bg-deepBrown/90 backdrop-blur-md text-parchment p-4 border-b-2 border-gold/40 shadow-xl relative z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center gap-4 group">
          <motion.div 
            whileHover={{ rotate: 15, scale: 1.1 }}
            className="text-pirateRed"
          >
            <Skull className="w-8 h-8" />
          </motion.div>
          <span className="font-pirate text-3xl tracking-widest text-gold drop-shadow-md">
            GRAND LINE FORGE
          </span>
        </Link>
        
        <nav className="hidden md:flex items-center gap-8 font-display text-sm tracking-[0.15em] uppercase">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            
            return (
              <Link 
                key={item.path} 
                to={item.path} 
                className="relative group flex items-center gap-2"
              >
                <Icon className={`w-4 h-4 transition-colors ${isActive ? 'text-gold' : 'text-parchment/60 group-hover:text-gold/80'}`} />
                <span className={`transition-colors ${isActive ? 'text-gold font-bold' : 'text-parchment/80 group-hover:text-gold/80'}`}>
                  {item.label}
                </span>
                
                {/* Active Indicator */}
                {isActive && (
                  <motion.div 
                    layoutId="activeNav"
                    className="absolute -bottom-6 left-0 right-0 h-1 bg-gold shadow-[0_0_10px_rgba(212,175,55,0.8)]"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                )}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
