import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Compass, Ship } from 'lucide-react';
import TeamReveal from '../components/TeamReveal';
import FormationHeader from '../components/formation/FormationHeader';
import FormationAlgorithmLoader from '../components/formation/FormationAlgorithmLoader';
import TeamSizeSelector from '../components/formation/TeamSizeSelector';

export default function CrewFormation() {
  const { participants, setCrews, crews } = useStore();
  const [isForming, setIsForming] = useState(false);
  const [teamSize, setTeamSize] = useState(3);
  const navigate = useNavigate();

  const handleFormCrews = () => {
    setIsForming(true);
    
    // Simulate cinematic formation steps (4 phases * 1500ms = 6000ms)
    setTimeout(() => {
      const newCrews = [];
      let currentCrew = [];
      
      [...participants].forEach((p, i) => {
        currentCrew.push(p);
        if (currentCrew.length === teamSize || i === participants.length - 1) {
          newCrews.push({
            id: `crew-${i}`,
            name: `Crew ${newCrews.length + 1}`,
            members: [...currentCrew],
            balanceScore: Math.floor(Math.random() * 20) + 80 // Mock score 80-99
          });
          currentCrew = [];
        }
      });
      
      setCrews(newCrews);
      setIsForming(false);
    }, 6000);
  };

  if (participants.length < 3) {
    return (
      <div className="max-w-4xl mx-auto p-6 my-12 text-center relative z-10 bg-darkBrown/80 backdrop-blur-md rounded-2xl border border-gold/30">
        <h1 className="text-4xl font-display text-pirateRed mb-4 drop-shadow-md">Not Enough Recruits</h1>
        <p className="text-xl text-parchment/80 mb-8 font-sans">You need at least {teamSize} recruits in the system to form a proper crew of size {teamSize}. Currently have {participants.length}.</p>
        <Link to="/recruit" className="inline-block px-8 py-4 bg-gold/20 border-2 border-gold text-gold rounded hover:bg-gold hover:text-black font-display tracking-widest transition-all">
          Back to Recruitment
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 my-8 relative z-10">
      <FormationHeader />

      <AnimatePresence mode="wait">
        {crews.length === 0 && !isForming && (
          <motion.div 
            key="init"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="text-center mt-12"
          >
            <TeamSizeSelector teamSize={teamSize} setTeamSize={setTeamSize} />
            <motion.button 
              whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(212,175,55,0.4)' }}
              whileTap={{ scale: 0.95 }}
              onClick={handleFormCrews} 
              className="px-12 py-6 bg-gradient-to-r from-pirateRed to-red-900 border-2 border-gold text-parchment font-display tracking-[0.2em] text-2xl rounded-xl shadow-[0_15px_30px_rgba(186,12,12,0.4)] transition-all"
            >
              <Compass className="inline-block w-8 h-8 mr-3 animate-spin-slow" />
              COMMENCE FORMATION
            </motion.button>
          </motion.div>
        )}

        {isForming && (
          <motion.div key="forming" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <FormationAlgorithmLoader />
          </motion.div>
        )}

        {crews.length > 0 && !isForming && (
          <motion.div 
            key="results"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6 bg-black/40 p-6 rounded-xl border border-gold/20">
              <h2 className="text-3xl lg:text-4xl font-display text-gold drop-shadow-md">
                The Grand Fleet is Ready
              </h2>
              <Link 
                to="/challenge" 
                className="flex items-center gap-2 px-8 py-3 bg-pirateRed/90 hover:bg-pirateRed border border-pirateRed text-parchment font-display tracking-widest text-lg rounded shadow-lg transition-all"
              >
                <Ship className="w-5 h-5" />
                Assign Challenges
              </Link>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
              {crews.map((crew, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + (i * 0.2), duration: 0.5 }}
                  key={crew.id}
                  className="h-full"
                >
                  <TeamReveal crew={crew} />
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
